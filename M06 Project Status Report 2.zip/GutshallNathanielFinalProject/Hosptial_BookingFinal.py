import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os

# File path for storing appointments
APPOINTMENT_FILE = "appointments.txt"
# File path for logo image
LOGO_PATH = r"A:\Python\Hosptial.png"  # Updated logo file path

# Function to load and resize the hospital logo
# This function attempts to load the hospital logo from a given file path
# If successful, it returns a resized image to be used in the GUI.
def load_logo_image():
    try:
        # Attempt to open the logo image from the file path
        image = Image.open(LOGO_PATH)
        # Resize the image to a reasonable size (150x150 pixels) for display
        image = image.resize((150, 150), Image.Resampling.LANCZOS)
        # Convert the image to a Tkinter-compatible format
        logo_image = ImageTk.PhotoImage(image)
        return logo_image
    except Exception as e:
        # Print any error that occurs while loading the image
        print("Error loading logo: " + str(e))
        return None  # Return None if the image cannot be loaded

# Function to validate if the name entered is valid
# The name must not be empty and must only contain letters
def validate_name(name):
    return name.strip() != "" and name.replace(" ", "").isalpha()

# Function to validate if the entered age is a valid number
# The age must be a positive number
def validate_age(age):
    return age.isdigit() and int(age) > 0

# Function to load the list of appointments from a file
# This function reads the appointment data from the text file and returns a list of appointments
def load_appointments():
    appts = []  # Initialize an empty list to store the appointments
    if os.path.exists(APPOINTMENT_FILE):  # Check if the file exists
        with open(APPOINTMENT_FILE, "r") as file:
            for line in file:
                parts = line.strip().split(" | ")  # Split the line into parts (name, age, doctor, time)
                if len(parts) == 4:  # Ensure the line has exactly 4 parts (valid data)
                    appts.append(tuple(parts))  # Add the appointment to the list as a tuple
    return appts  # Return the list of appointments

# Function to save the current list of appointments to the file
# This function writes the appointments list to the text file for persistence
def save_appointments():
    with open(APPOINTMENT_FILE, "w") as file:  # Open the file for writing
        for appt in appointments:  # Iterate over each appointment in the list
            file.write(" | ".join(appt) + "\n")  # Write the appointment to the file, separated by ' | '

# Helper function to place the logo image in the window
# This function displays the logo in the provided Tkinter window
def place_logo(window, logo_image):
    if logo_image:
        # If the logo image is available, create a label with the image and pack it in the window
        tk.Label(window, image=logo_image).pack(pady=10)
        window.logo_ref = logo_image  # Store a reference to the image to prevent garbage collection
    else:
        # If the logo image is not available, display a placeholder text
        tk.Label(window, text="[Hospital Logo]").pack(pady=10)

# Function to display the welcome screen
# This is the initial screen that users see when they start the application
def show_welcome_screen():
    global appointments  # Global variable for storing appointments
    appointments[:] = load_appointments()  # Load appointments from the file

    root = tk.Tk()  # Create a new Tkinter window
    root.title("Hospital Booking System")  # Set the title of the window
    root.state('zoomed')  # Maximize the window

    logo_image = load_logo_image()  # Load the logo image
    place_logo(root, logo_image)  # Place the logo in the window

    # Label to display the welcome message
    tk.Label(root, text="Welcome to the Hospital Appointment Booking System", font=("Times New Roman", 14)).pack(pady=10)
    # Button to navigate to the main menu
    tk.Button(root, text="Start", width=20, command=lambda: open_main_menu(root)).pack(pady=30)

    root.mainloop()  # Start the Tkinter event loop to display the window

# Function to open the main menu screen
# This screen allows the user to choose between booking an appointment, viewing, or canceling appointments
def open_main_menu(previous_window):
    previous_window.destroy()  # Destroy the previous window (welcome screen)
    window = tk.Tk()  # Create a new Tkinter window for the main menu
    window.title("Main Menu")  # Set the title of the window
    window.state('zoomed')  # Maximize the window

    logo_image = load_logo_image()  # Load the logo image
    place_logo(window, logo_image)  # Place the logo in the window

    # Label for the main menu title
    tk.Label(window, text="Main Menu", font=("Times New Roman", 16)).pack(pady=10)
    # Buttons for each of the options (Book Appointment, View Appointments, etc.)
    tk.Button(window, text="Book Appointment", width=25, command=lambda: open_booking_screen(window)).pack(pady=10)
    tk.Button(window, text="View Appointments", width=25, command=lambda: view_appointments(window)).pack(pady=10)
    tk.Button(window, text="Cancel Appointment", width=25, command=lambda: cancel_appointment(window)).pack(pady=10)
    tk.Button(window, text="Exit", width=25, command=window.quit).pack(pady=10)

# Function to open the booking screen
# This screen allows users to book a new appointment by providing their details
appointments = []  # Global variable for storing the list of appointments

def open_booking_screen(parent_window):
    parent_window.destroy()  # Destroy the previous window (main menu)
    win = tk.Tk()  # Create a new Tkinter window for booking an appointment
    win.title("Book Appointment")  # Set the title of the window
    win.state('zoomed')  # Maximize the window

    logo_image = load_logo_image()  # Load the logo image
    place_logo(win, logo_image)  # Place the logo in the window

    # Label for the booking screen title
    tk.Label(win, text="Book an Appointment", font=("Times New Roman", 14)).pack(pady=10)

    # Entry fields for user input
    tk.Label(win, text="Name:").pack()  # Label for the Name field
    name_entry = tk.Entry(win)  # Entry widget for the user to input their name
    name_entry.pack()

    tk.Label(win, text="Age:").pack()  # Label for the Age field
    age_entry = tk.Entry(win)  # Entry widget for the user to input their age
    age_entry.pack()

    tk.Label(win, text="Doctor (e.g., Dr. Smith):").pack()  # Label for the Doctor field
    doctor_entry = tk.Entry(win)  # Entry widget for the user to input the doctor's name
    doctor_entry.pack()

    tk.Label(win, text="Time (e.g., 10:00 AM):").pack()  # Label for the Time field
    time_entry = tk.Entry(win)  # Entry widget for the user to input the appointment time
    time_entry.pack()

    # Function to submit the appointment details
    def submit():
        name = name_entry.get()  # Get the entered name
        age = age_entry.get()  # Get the entered age
        doctor = doctor_entry.get()  # Get the entered doctor's name
        time = time_entry.get()  # Get the entered time

        # Validate the input fields
        if not validate_name(name):
            messagebox.showerror("Error", "Please enter a valid name.")  # Show error if name is invalid
            return
        if not validate_age(age):
            messagebox.showerror("Error", "Please enter a valid age.")  # Show error if age is invalid
            return
        if not doctor or not time:
            messagebox.showerror("Error", "Doctor and time fields cannot be empty.")  # Show error if doctor or time is empty
            return

        # Append the valid appointment to the appointments list
        appointments.append((name, age, doctor, time))
        save_appointments()  # Save the updated list of appointments
        messagebox.showinfo("Success", "Appointment booked!")  # Show success message
        open_main_menu(win)  # Return to the main menu

    tk.Button(win, text="Confirm Booking", command=submit).pack(pady=10)  # Button to confirm booking
    tk.Button(win, text="Back to Menu", command=lambda: open_main_menu(win)).pack()  # Button to go back to the main menu

# Function to view all appointments
# This screen shows the list of all upcoming appointments
def view_appointments(window):
    window.destroy()  # Destroy the previous window (main menu)
    win = tk.Tk()  # Create a new Tkinter window for viewing appointments
    win.title("All Appointments")  # Set the title of the window
    win.state('zoomed')  # Maximize the window

    logo_image = load_logo_image()  # Load the logo image
    place_logo(win, logo_image)  # Place the logo in the window

    # Label for the appointments list title
    tk.Label(win, text="Upcoming Appointments", font=("Times New Roman", 14)).pack(pady=10)

    # If no appointments are available, display a message
    if not appointments:
        tk.Label(win, text="No appointments yet.").pack()
    else:
        # Display each appointment in the list
        for i, appt in enumerate(appointments):
            info = str(i+1) + ". " + appt[0] + " (" + appt[1] + "), with " + appt[2] + " at " + appt[3]
            tk.Label(win, text=info).pack(anchor="w")  # Display each appointment as a label

    tk.Button(win, text="Back to Menu", command=lambda: open_main_menu(win)).pack(pady=10)  # Button to go back to the main menu

# Function to cancel an appointment
# This screen allows users to select and cancel an existing appointment
def cancel_appointment(window):
    window.destroy()  # Destroy the previous window (main menu)
    win = tk.Tk()  # Create a new Tkinter window for canceling an appointment
    win.title("Cancel Appointment")  # Set the title of the window
    win.state('zoomed')  # Maximize the window

    logo_image = load_logo_image()  # Load the logo image
    place_logo(win, logo_image)  # Place the logo in the window

    # Label for the cancel appointment screen title
    tk.Label(win, text="Select Appointment to Cancel", font=("Times New Roman", 14)).pack(pady=10)

    # If no appointments are available to cancel, display a message
    if not appointments:
        tk.Label(win, text="No appointments to cancel.").pack()
    else:
        var = tk.IntVar()  # Variable to store the selected appointment index
        # Create a radio button for each appointment in the list
        for i, appt in enumerate(appointments):
            label = str(i+1) + ". " + appt[0] + " with " + appt[2] + " at " + appt[3]
            tk.Radiobutton(win, text=label, variable=var, value=i).pack(anchor="w")

        # Function to confirm the cancellation of the selected appointment
        def confirm_cancel():
            idx = var.get()  # Get the selected appointment index
            if 0 <= idx < len(appointments):  # If the selected index is valid
                del appointments[idx]  # Delete the selected appointment from the list
                save_appointments()  # Save the updated list of appointments
                messagebox.showinfo("Cancelled", "Appointment successfully cancelled.")  # Show success message
                open_main_menu(win)  # Return to the main menu
            else:
                messagebox.showerror("Error", "Please select an appointment to cancel.")  # Show error if no appointment is selected

        tk.Button(win, text="Cancel Selected Appointment", command=confirm_cancel).pack(pady=10)  # Button to confirm cancellation

    tk.Button(win, text="Back to Menu", command=lambda: open_main_menu(win)).pack()  # Button to go back to the main menu

# Start the program
show_welcome_screen()  # Show the welcome screen when the program starts
